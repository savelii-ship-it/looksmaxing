import { PrismaClient } from "@prisma/client";
const g = globalThis as any;
export const db: PrismaClient = g.__db ?? (g.__db = new PrismaClient());
