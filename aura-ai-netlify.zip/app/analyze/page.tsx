import Uploader from "@/components/Uploader";
export default function A() { return <><h1 className="text-3xl font-bold mb-6">Новый анализ</h1><Uploader /><p className="opacity-50 text-xs mt-4">Фото обрабатываются нейросетью и не сохраняются. Результат — вероятностные наблюдения, не диагноз.</p></>; }
