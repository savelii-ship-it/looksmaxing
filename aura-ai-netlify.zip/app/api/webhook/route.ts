import { NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
// В @CryptoBot -> Crypto Pay -> приложение -> Webhooks укажите https://ВАШ-САЙТ/api/webhook
export async function POST(req: Request) {
  const raw = await req.text();
  const key = crypto.createHash("sha256").update(process.env.CRYPTO_PAY_TOKEN || "").digest();
  const sig = crypto.createHmac("sha256", key).update(raw).digest("hex");
  const got = req.headers.get("crypto-pay-api-signature") || "";
  if (got.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(got), Buffer.from(sig))) return NextResponse.json({ error: "bad sig" }, { status: 401 });
  const ev = JSON.parse(raw);
  if (ev.update_type !== "invoice_paid") return NextResponse.json({ ok: true });
  const pay = await db.payment.findUnique({ where: { invoiceId: String(ev.payload.invoice_id) } });
  if (!pay || pay.status === "paid") return NextResponse.json({ ok: true });
  const u = await db.user.findUnique({ where: { id: pay.userId } });
  if (!u) return NextResponse.json({ ok: true });
  const active = !!u.planUntil && u.planUntil > new Date() && u.plan === pay.plan;
  const base = active ? u.planUntil! : new Date();
  await db.$transaction([
    db.payment.update({ where: { id: pay.id }, data: { status: "paid" } }),
    db.user.update({ where: { id: u.id }, data: { plan: pay.plan, planUntil: new Date(base.getTime() + 30 * 864e5), used: active ? u.used : 0 } }),
  ]);
  return NextResponse.json({ ok: true });
}
