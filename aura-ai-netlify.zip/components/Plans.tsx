"use client";
import { useState } from "react";
const P = [
  { k: "FREE", n: "Free", p: "0", f: ["1 анализ", "Полный отчёт"] },
  { k: "PRO", n: "Pro", p: process.env.NEXT_PUBLIC_PRO_PRICE || "9", f: ["50 анализов", "30 дней", "История"] },
  { k: "VIP", n: "VIP", p: process.env.NEXT_PUBLIC_VIP_PRICE || "29", f: ["Безлимит", "30 дней", "Приоритет"] },
];
export default function Plans() {
  const [busy, setBusy] = useState("");
  async function buy(plan: string) {
    setBusy(plan);
    const r = await fetch("/api/pay", { method: "POST", body: JSON.stringify({ plan }) });
    const j = await r.json();
    if (j.url) location.href = j.url; else { setBusy(""); if (r.status === 401) location.href = "/login"; else alert(j.error); }
  }
  return (
    <div className="grid gap-4 md:grid-cols-3">
      {P.map((x) => (
        <div key={x.k} className={"glass p-6 " + (x.k === "PRO" ? "ring-1 ring-acc" : "")}>
          <h3 className="text-xl font-semibold">{x.n}</h3>
          <p className="text-4xl font-bold my-3">{x.p}<span className="text-base opacity-60"> USDT</span></p>
          <ul className="opacity-80 text-sm mb-5 space-y-1">{x.f.map((f) => <li key={f}>✓ {f}</li>)}</ul>
          {x.k === "FREE" ? <a href="/register" className="btn btn2 w-full">Начать</a> : <button className="btn w-full" disabled={!!busy} onClick={() => buy(x.k)}>{busy === x.k ? "..." : "Оплатить"}</button>}
        </div>
      ))}
    </div>
  );
}
