import Link from "next/link";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { PLANS, activePlan } from "@/lib/plans";
export default async function D() {
  const s = await getServerSession(authOptions); const id = (s?.user as any)?.id;
  if (!id) redirect("/login");
  const u = await db.user.findUnique({ where: { id }, include: { analyses: { orderBy: { createdAt: "desc" }, take: 30 }, payments: { orderBy: { createdAt: "desc" }, take: 20 } } });
  if (!u) redirect("/login");
  const p = activePlan(u); const lim = PLANS[p].limit;
  return (<div className="space-y-5">
    <div className="glass p-6"><p className="opacity-60 text-sm">{u.email}</p><h1 className="text-2xl font-bold">Тариф {p}</h1>
      <p className="opacity-80">Использовано: {u.used} / {lim === Infinity ? "∞" : lim}{p !== "FREE" && u.planUntil && ` · до ${u.planUntil.toLocaleDateString("ru")}`}</p>
      <div className="flex gap-2 mt-4"><Link href="/analyze" className="btn">Новый анализ</Link><Link href="/pricing" className="btn btn2">{p === "FREE" ? "Улучшить" : "Продлить"}</Link>{u.role === "ADMIN" && <Link href="/admin" className="btn btn2">Админ</Link>}</div></div>
    <div className="glass p-6"><h2 className="font-semibold mb-3">История анализов</h2>{u.analyses.length ? u.analyses.map((a) => <Link key={a.id} href={"/analysis/" + a.id} className="block py-2 border-b border-white/10 text-sm">{a.createdAt.toLocaleString("ru")} →</Link>) : <p className="opacity-60 text-sm">Пока пусто</p>}</div>
    <div className="glass p-6"><h2 className="font-semibold mb-3">История платежей</h2>{u.payments.length ? u.payments.map((x) => <p key={x.id} className="py-2 border-b border-white/10 text-sm">{x.createdAt.toLocaleDateString("ru")} · {x.plan} · {x.amount} USDT · {x.status === "paid" ? "оплачен" : "ожидает"}</p>) : <p className="opacity-60 text-sm">Платежей нет</p>}</div>
  </div>);
}
