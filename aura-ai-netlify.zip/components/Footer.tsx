import Link from "next/link";
export default function Footer() {
  return <footer className="max-w-5xl mx-auto px-4 pb-10 text-xs opacity-60 flex flex-wrap gap-4 justify-center"><Link href="/info/privacy">Конфиденциальность</Link><Link href="/info/terms">Соглашение</Link><Link href="/info/faq">FAQ</Link><Link href="/info/contacts">Контакты</Link></footer>;
}
