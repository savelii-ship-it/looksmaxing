import { getServerSession } from "next-auth";
import { notFound } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import AdminBtns from "@/components/AdminBtns";
export const dynamic = "force-dynamic";
export default async function Admin() {
  const s = await getServerSession(authOptions); const id = (s?.user as any)?.id;
  const me = id ? await db.user.findUnique({ where: { id } }) : null;
  if (me?.role !== "ADMIN") notFound();
  const [users, payments, nAn, rev, week] = await Promise.all([
    db.user.findMany({ orderBy: { createdAt: "desc" }, take: 100 }),
    db.payment.findMany({ orderBy: { createdAt: "desc" }, take: 50, include: { user: true } }),
    db.analysis.count(), db.payment.aggregate({ where: { status: "paid" }, _sum: { amount: true } }),
    db.user.count({ where: { createdAt: { gt: new Date(Date.now() - 7 * 864e5) } } }),
  ]);
  return (<div className="space-y-5">
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{[["Пользователи", users.length], ["Регистрации 7д", week], ["Анализы", nAn], ["Доход USDT", rev._sum.amount || 0]].map(([k, v]) => <div key={k as string} className="glass p-4"><p className="opacity-60 text-xs">{k}</p><p className="text-2xl font-bold">{v}</p></div>)}</div>
    <div className="glass p-4 overflow-x-auto"><h2 className="font-semibold mb-2">Пользователи</h2>{users.map((u) => <div key={u.id} className="py-2 border-b border-white/10 text-sm flex flex-col gap-1"><span>{u.email} · {u.plan}{u.planUntil ? " до " + u.planUntil.toLocaleDateString("ru") : ""} · {u.used} ан.{u.blocked ? " · 🚫" : ""}</span>{u.id !== me!.id && <AdminBtns id={u.id} blocked={u.blocked} />}</div>)}</div>
    <div className="glass p-4"><h2 className="font-semibold mb-2">Платежи</h2>{payments.map((p) => <p key={p.id} className="text-sm py-1 border-b border-white/10">{p.createdAt.toLocaleDateString("ru")} · {p.user.email} · {p.plan} · {p.amount} · {p.status}</p>)}</div>
  </div>);
}
