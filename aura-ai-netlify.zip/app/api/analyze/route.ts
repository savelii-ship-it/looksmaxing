import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { ai } from "@/lib/ai";
import { PLANS, activePlan, rateLimit } from "@/lib/plans";
export async function POST(req: Request) {
  const s = await getServerSession(authOptions);
  const id = (s?.user as any)?.id;
  if (!id) return NextResponse.json({ error: "Войдите в аккаунт" }, { status: 401 });
  if (!rateLimit("an" + id, 5, 60000)) return NextResponse.json({ error: "Слишком часто" }, { status: 429 });
  const u = await db.user.findUnique({ where: { id } });
  if (!u || u.blocked) return NextResponse.json({ error: "Доступ закрыт" }, { status: 403 });
  const p = activePlan(u);
  if (u.used >= PLANS[p].limit) return NextResponse.json({ error: "Лимит исчерпан. Выберите тариф.", paywall: true }, { status: 402 });
  const { images } = await req.json();
  if (!Array.isArray(images) || !images.length || images.length > 5 || images.some((x: any) => typeof x !== "string" || x.length > 1_500_000))
    return NextResponse.json({ error: "Нужно от 1 до 5 фото" }, { status: 400 });
  try {
    const result = await ai.analyze(images);
    const a = await db.analysis.create({ data: { userId: id, result } });
    await db.user.update({ where: { id }, data: { used: { increment: 1 } } });
    return NextResponse.json({ id: a.id });
  } catch { return NextResponse.json({ error: "Сбой анализа, попробуйте позже" }, { status: 502 }); }
}
