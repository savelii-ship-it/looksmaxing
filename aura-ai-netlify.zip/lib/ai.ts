// Универсальный адаптер. Чтобы сменить модель — реализуйте AIProvider и поменяйте экспорт `ai`.
export interface AIProvider { analyze(images: string[]): Promise<string>; }
const PROMPT = `Ты — эксперт по визуальному стилю и уходу. Проанализируй фото и составь отчёт на русском в разделах:
1. Общее впечатление 2. Черты лица (форма лица, баланс пропорций, кожа на фото) 3. Сильные стороны 4. Рекомендации (причёска, уход за кожей, стиль, освещение/ракурс для фото) 5. Итог.
Правила: это только наблюдения по изображению, формулируй вероятностно («похоже», «возможно»). Не ставь медицинских диагнозов, не делай категоричных выводов о личности, здоровье, возрасте, расе. Будь доброжелателен. Если лица на фото нет или оно неразборчиво — скажи об этом и дай совет, как переснять.`;
class AnthropicProvider implements AIProvider {
  async analyze(images: string[]) {
    const content: any[] = images.map((d) => {
      const m = d.match(/^data:(image\/\w+);base64,(.+)$/);
      if (!m) throw new Error("bad image");
      return { type: "image", source: { type: "base64", media_type: m[1], data: m[2] } };
    });
    content.push({ type: "text", text: PROMPT });
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.AI_API_KEY!, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.AI_MODEL || "claude-sonnet-4-5", max_tokens: 900, messages: [{ role: "user", content }] }),
    });
    if (!r.ok) throw new Error("AI error " + r.status);
    const j = await r.json();
    return (j.content || []).map((c: any) => c.text || "").join("\n");
  }
}
class GeminiProvider implements AIProvider {
  async analyze(images: string[]) {
    const parts: any[] = images.map((d) => {
      const m = d.match(/^data:(image\/\w+);base64,(.+)$/);
      if (!m) throw new Error("bad image");
      return { inline_data: { mime_type: m[1], data: m[2] } };
    });
    parts.push({ text: PROMPT });
    const model = process.env.AI_MODEL || "gemini-2.5-flash";
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": process.env.AI_API_KEY! },
      body: JSON.stringify({ contents: [{ parts }], generationConfig: { maxOutputTokens: 1500 } }),
    });
    if (!r.ok) throw new Error("AI error " + r.status);
    const j = await r.json();
    return (j.candidates?.[0]?.content?.parts || []).map((c: any) => c.text || "").join("\n");
  }
}
// AI_PROVIDER=gemini (бесплатно) или anthropic (платно)
export const ai: AIProvider = process.env.AI_PROVIDER === "anthropic" ? new AnthropicProvider() : new GeminiProvider();
