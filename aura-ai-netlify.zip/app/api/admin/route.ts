import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
export async function POST(req: Request) {
  const s = await getServerSession(authOptions);
  const mid = (s?.user as any)?.id;
  const me = mid ? await db.user.findUnique({ where: { id: mid } }) : null;
  if (!me || me.role !== "ADMIN") return NextResponse.json({ error: "no" }, { status: 403 });
  const { action, userId, plan } = await req.json();
  if (userId === me.id) return NextResponse.json({ error: "self" }, { status: 400 });
  if (action === "grant" && ["PRO", "VIP"].includes(plan)) await db.user.update({ where: { id: userId }, data: { plan, planUntil: new Date(Date.now() + 30 * 864e5), used: 0 } });
  if (action === "block") await db.user.update({ where: { id: userId }, data: { blocked: true } });
  if (action === "unblock") await db.user.update({ where: { id: userId }, data: { blocked: false } });
  if (action === "delete") await db.user.delete({ where: { id: userId } });
  return NextResponse.json({ ok: true });
}
