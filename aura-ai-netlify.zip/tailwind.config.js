module.exports={content:["./app/**/*.{ts,tsx}","./components/**/*.{ts,tsx}"],theme:{extend:{colors:{ink:"#07070d",acc:"#a78bfa",acc2:"#38bdf8"}}},plugins:[]}
