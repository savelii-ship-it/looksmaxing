export const PLANS = {
  FREE: { limit: 1, price: 0, label: "1 анализ" },
  PRO: { limit: 50, price: Number(process.env.PRO_PRICE || 9), label: "50 анализов / 30 дней" },
  VIP: { limit: Infinity, price: Number(process.env.VIP_PRICE || 29), label: "Безлимит / 30 дней" },
} as const;
export type PlanKey = keyof typeof PLANS;
export function activePlan(u: { plan: string; planUntil: Date | null }): PlanKey {
  return u.plan !== "FREE" && u.planUntil && u.planUntil > new Date() ? (u.plan as PlanKey) : "FREE";
}
const hits = new Map<string, number[]>();
export function rateLimit(key: string, max = 10, windowMs = 60000) {
  const now = Date.now();
  const a = (hits.get(key) || []).filter((t) => now - t < windowMs);
  a.push(now); hits.set(key, a);
  return a.length <= max;
}
