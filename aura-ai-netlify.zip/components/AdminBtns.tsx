"use client";
export default function AdminBtns({ id, blocked }: { id: string; blocked: boolean }) {
  async function a(action: string, plan?: string) { if (action === "delete" && !confirm("Удалить пользователя?")) return; await fetch("/api/admin", { method: "POST", body: JSON.stringify({ action, userId: id, plan }) }); location.reload(); }
  return <div className="flex gap-1 flex-wrap text-xs">{["PRO", "VIP"].map((p) => <button key={p} className="btn btn2 !p-1.5" onClick={() => a("grant", p)}>+{p}</button>)}<button className="btn btn2 !p-1.5" onClick={() => a(blocked ? "unblock" : "block")}>{blocked ? "Разблок" : "Блок"}</button><button className="btn btn2 !p-1.5" onClick={() => a("delete")}>Удалить</button></div>;
}
