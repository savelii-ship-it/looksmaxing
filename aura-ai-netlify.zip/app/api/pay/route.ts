import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { PLANS } from "@/lib/plans";
export async function POST(req: Request) {
  const s = await getServerSession(authOptions);
  const id = (s?.user as any)?.id;
  if (!id) return NextResponse.json({ error: "Войдите" }, { status: 401 });
  const { plan } = await req.json();
  if (plan !== "PRO" && plan !== "VIP") return NextResponse.json({ error: "Неверный тариф" }, { status: 400 });
  const amount = PLANS[plan as "PRO" | "VIP"].price;
  const r = await fetch((process.env.CRYPTO_PAY_API || "https://pay.crypt.bot/api") + "/createInvoice", {
    method: "POST",
    headers: { "Crypto-Pay-API-Token": process.env.CRYPTO_PAY_TOKEN!, "content-type": "application/json" },
    body: JSON.stringify({ asset: "USDT", amount: String(amount), description: "Aura " + plan + " 30 дней", payload: id + ":" + plan, expires_in: 3600 }),
  });
  const j = await r.json();
  if (!j.ok) return NextResponse.json({ error: "Не удалось создать счёт" }, { status: 502 });
  await db.payment.create({ data: { userId: id, invoiceId: String(j.result.invoice_id), plan, amount } });
  return NextResponse.json({ url: j.result.bot_invoice_url });
}
