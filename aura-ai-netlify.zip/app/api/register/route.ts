import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { rateLimit } from "@/lib/plans";
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for") || "x";
  if (!rateLimit("reg" + ip, 5, 600000)) return NextResponse.json({ error: "Слишком много попыток" }, { status: 429 });
  const { email, password, name } = await req.json();
  const e = String(email || "").toLowerCase().trim();
  if (!/^\S+@\S+\.\S+$/.test(e) || String(password || "").length < 8) return NextResponse.json({ error: "Проверьте email и пароль (от 8 символов)" }, { status: 400 });
  if (await db.user.findUnique({ where: { email: e } })) return NextResponse.json({ error: "Email уже занят" }, { status: 409 });
  await db.user.create({ data: { email: e, name: String(name || "").slice(0, 60), passwordHash: await bcrypt.hash(password, 10), role: process.env.ADMIN_EMAIL?.toLowerCase() === e ? "ADMIN" : "USER" } });
  return NextResponse.json({ ok: true });
}
