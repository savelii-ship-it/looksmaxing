"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function go(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr("");
    const f = Object.fromEntries(new FormData(e.currentTarget)) as any;
    if (f.website) return; // honeypot
    if (mode === "register") {
      const r = await fetch("/api/register", { method: "POST", body: JSON.stringify(f) });
      if (!r.ok) { setErr((await r.json()).error); setBusy(false); return; }
    }
    const r = await signIn("credentials", { email: f.email, password: f.password, redirect: false });
    if (r?.error) { setErr("Неверный email или пароль"); setBusy(false); } else location.href = "/dashboard";
  }
  return (
    <form onSubmit={go} className="glass p-6 max-w-sm mx-auto space-y-3 up">
      <h1 className="text-2xl font-bold">{mode === "login" ? "Вход" : "Регистрация"}</h1>
      {mode === "register" && <input name="name" placeholder="Имя" className="inp" />}
      <input name="email" type="email" required placeholder="Email" className="inp" autoComplete="email" />
      <input name="password" type="password" required minLength={8} placeholder="Пароль (от 8 символов)" className="inp" autoComplete={mode === "login" ? "current-password" : "new-password"} />
      <input name="website" tabIndex={-1} autoComplete="off" className="hidden" />
      {err && <p className="text-red-400 text-sm">{err}</p>}
      <label className="flex gap-2 text-xs opacity-70 items-start"><input type="checkbox" required className="mt-0.5" />Мне 18+, я принимаю <a href="/info/terms" className="underline">соглашение</a> и <a href="/info/privacy" className="underline">политику конфиденциальности</a></label>
      <button className="btn w-full" disabled={busy}>{busy ? "..." : "Продолжить"}</button>
      <a className="block text-center text-sm opacity-70" href={mode === "login" ? "/register" : "/login"}>{mode === "login" ? "Создать аккаунт" : "Уже есть аккаунт"}</a>
    </form>
  );
}
