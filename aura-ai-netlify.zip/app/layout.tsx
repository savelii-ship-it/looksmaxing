import "./globals.css";
import Script from "next/script";
import type { Metadata, Viewport } from "next";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
const url = process.env.NEXTAUTH_URL || "http://localhost:3000";
export const metadata: Metadata = {
  metadataBase: new URL(url), title: "Aura — AI-анализ внешности по фото", description: "Персональный отчёт о чертах лица и рекомендации по стилю и уходу.",
  openGraph: { title: "Aura — AI-анализ внешности", description: "Загрузите фото и получите персональный отчёт.", type: "website" },
  twitter: { card: "summary_large_image", title: "Aura — AI-анализ внешности" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover", themeColor: "#07070d" };
export default function Root({ children }: { children: React.ReactNode }) {
  const ga = process.env.NEXT_PUBLIC_GA_ID;
  return (
    <html lang="ru"><body>
      {ga && <><Script src={`https://www.googletagmanager.com/gtag/js?id=${ga}`} strategy="afterInteractive" /><Script id="ga" strategy="afterInteractive">{`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','${ga}')`}</Script></>}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({ "@context": "https://schema.org", "@type": "WebApplication", name: "Aura", applicationCategory: "LifestyleApplication", url }) }} />
      <Nav /><main className="max-w-5xl mx-auto px-4 py-8" style={{ paddingBottom: "max(2rem, env(safe-area-inset-bottom))" }}>{children}</main><Footer />
    </body></html>
  );
}
