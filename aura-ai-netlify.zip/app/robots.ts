import type { MetadataRoute } from "next";
export default function robots(): MetadataRoute.Robots {
  const u = process.env.NEXTAUTH_URL || "http://localhost:3000";
  return { rules: { userAgent: "*", allow: "/", disallow: ["/admin", "/api", "/dashboard"] }, sitemap: u + "/sitemap.xml" };
}
