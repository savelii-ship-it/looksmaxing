import { getServerSession } from "next-auth";
import { notFound, redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
export default async function R({ params }: { params: Promise<{ id: string }> }) {
  const s = await getServerSession(authOptions); const uid = (s?.user as any)?.id;
  if (!uid) redirect("/login");
  const a = await db.analysis.findUnique({ where: { id: (await params).id } });
  if (!a || a.userId !== uid) notFound();
  return <article className="glass p-6 up"><h1 className="text-2xl font-bold mb-1">Результат анализа</h1><p className="opacity-50 text-sm mb-4">{a.createdAt.toLocaleString("ru")}</p><div className="whitespace-pre-wrap leading-relaxed">{a.result}</div><p className="opacity-50 text-xs mt-6">Это вероятностные наблюдения по изображению, а не медицинское заключение.</p></article>;
}
