import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
export default async function Nav() {
  const s = await getServerSession(authOptions);
  return (
    <header className="sticky top-0 z-10 glass !rounded-none !border-x-0 !border-t-0 px-4 py-3 flex items-center justify-between" style={{ paddingTop: "max(.75rem, env(safe-area-inset-top))" }}>
      <Link href="/" className="font-bold text-lg bg-gradient-to-r from-acc to-acc2 bg-clip-text text-transparent">Aura</Link>
      <nav className="flex gap-4 text-sm items-center">
        <Link href="/pricing">Тарифы</Link>
        {s ? <><Link href="/dashboard">Кабинет</Link><Link href="/api/auth/signout" className="opacity-60">Выйти</Link></> : <Link href="/login" className="btn !py-2 !px-4">Войти</Link>}
      </nav>
    </header>
  );
}
