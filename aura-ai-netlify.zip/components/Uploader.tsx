"use client";
import { useRef, useState } from "react";
type Img = { url: string; warn?: string };
async function prep(file: File): Promise<Img> {
  const bm = await createImageBitmap(file);
  const s = Math.min(1, 768 / Math.max(bm.width, bm.height));
  const c = document.createElement("canvas"); c.width = bm.width * s; c.height = bm.height * s;
  const x = c.getContext("2d")!; x.drawImage(bm, 0, 0, c.width, c.height);
  const d = x.getImageData(0, 0, c.width, c.height).data;
  let lum = 0, edge = 0;
  for (let i = 0; i < d.length; i += 16) { const l = d[i] * .3 + d[i + 1] * .6 + d[i + 2] * .1; lum += l; if (i > 16) edge += Math.abs(l - (d[i - 16] * .3 + d[i - 15] * .6 + d[i - 14] * .1)); }
  const n = d.length / 16; lum /= n; edge /= n;
  const warn = lum < 50 ? "Слишком тёмное фото" : lum > 220 ? "Пересвет" : edge < 3 ? "Фото размыто" : c.width < 300 ? "Низкое разрешение" : undefined;
  return { url: c.toDataURL("image/jpeg", 0.85), warn };
}
export default function Uploader() {
  const [imgs, setImgs] = useState<Img[]>([]); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  async function add(files: FileList | null) {
    if (!files) return;
    const list = await Promise.all(Array.from(files).filter((f) => f.type.startsWith("image/")).slice(0, 5 - imgs.length).map(prep));
    setImgs([...imgs, ...list].slice(0, 5));
  }
  async function send() {
    setBusy(true); setErr("");
    const r = await fetch("/api/analyze", { method: "POST", body: JSON.stringify({ images: imgs.map((i) => i.url) }) });
    const j = await r.json();
    if (r.ok) location.href = "/analysis/" + j.id; else { setErr(j.error); setBusy(false); if (j.paywall) setTimeout(() => (location.href = "/pricing"), 1500); if (r.status === 401) location.href = "/login"; }
  }
  return (
    <div className="space-y-4">
      <div className="glass p-8 text-center border-dashed" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); add(e.dataTransfer.files); }}>
        <p className="opacity-70 mb-4">Перетащите фото или выберите (до 5). Лицо крупно, хороший свет.</p>
        <input ref={ref} type="file" accept="image/*" multiple className="hidden" onChange={(e) => add(e.target.files)} />
        <div className="flex gap-2 justify-center">
          <button className="btn btn2" onClick={() => { ref.current!.removeAttribute("capture"); ref.current!.click(); }}>Галерея</button>
          <button className="btn btn2" onClick={() => { ref.current!.setAttribute("capture", "user"); ref.current!.click(); }}>Камера</button>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2">{imgs.map((i, k) => <div key={k} className="relative"><img src={i.url} className="rounded-xl aspect-square object-cover" />{i.warn && <span className="absolute bottom-1 left-1 right-1 text-[11px] bg-black/70 rounded px-1">⚠ {i.warn}</span>}<button onClick={() => setImgs(imgs.filter((_, j) => j !== k))} className="absolute top-1 right-1 bg-black/70 rounded-full w-6 h-6">×</button></div>)}</div>
      {err && <p className="text-red-400 text-sm">{err}</p>}
      <button className="btn w-full" disabled={!imgs.length || busy} onClick={send}>{busy ? "Анализируем… до 30 сек" : "Анализировать"}</button>
    </div>
  );
}
