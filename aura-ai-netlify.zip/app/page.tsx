import Link from "next/link";
import Plans from "@/components/Plans";
export default function Home() {
  return (<>
    <section className="text-center py-12 up">
      <h1 className="text-4xl md:text-6xl font-bold leading-tight">Узнайте, как вас <span className="bg-gradient-to-r from-acc to-acc2 bg-clip-text text-transparent">видит ИИ</span></h1>
      <p className="opacity-70 mt-4 max-w-xl mx-auto">Загрузите до 5 фото и получите подробный отчёт о чертах лица и рекомендации по стилю и уходу.</p>
      <div className="flex gap-3 justify-center mt-8"><Link href="/analyze" className="btn">Попробовать бесплатно</Link><Link href="/info/faq" className="btn btn2">FAQ</Link></div>
    </section>
    <section className="grid md:grid-cols-3 gap-4 mb-12">{[["📸","Камера или галерея","Проверка качества и света до отправки"],["🧠","Мультимодальный ИИ","Вероятностные наблюдения, без диагнозов"],["🔒","Приватность","Фото не хранятся на сервере"]].map(([i,t,d]) => <div key={t} className="glass p-5"><div className="text-2xl">{i}</div><h3 className="font-semibold mt-2">{t}</h3><p className="opacity-70 text-sm">{d}</p></div>)}</section>
    <Plans />
  </>);
}
