import type { MetadataRoute } from "next";
export default function sitemap(): MetadataRoute.Sitemap {
  const u = process.env.NEXTAUTH_URL || "http://localhost:3000";
  return ["", "/pricing", "/info/faq", "/info/privacy", "/info/terms", "/info/contacts"].map((p) => ({ url: u + p }));
}
