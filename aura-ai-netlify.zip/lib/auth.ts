import type { NextAuthOptions } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { db } from "./db";
export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [Credentials({
    credentials: { email: {}, password: {} },
    async authorize(c) {
      if (!c?.email || !c.password) return null;
      const u = await db.user.findUnique({ where: { email: c.email.toLowerCase().trim() } });
      if (!u || u.blocked || !(await bcrypt.compare(c.password, u.passwordHash))) return null;
      return { id: u.id, email: u.email, name: u.name };
    },
  })],
  callbacks: {
    async jwt({ token, user }) { if (user) token.uid = user.id; return token; },
    async session({ session, token }) { (session.user as any).id = token.uid; return session; },
  },
};
