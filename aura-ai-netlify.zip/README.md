# Aura — деплой на Netlify с iPhone

1. github.com (Safari) → New repository → Add file → Upload files: загрузите все файлы из распакованного ZIP (включая папки и файл `.npmrc`, `netlify.toml`).
2. neon.tech → бесплатная регистрация → New project → скопируйте Connection string (postgresql://…).
3. app.netlify.com → Add new site → Import from Git → выберите репозиторий. Настройки сборки подхватятся из netlify.toml.
4. Site configuration → Environment variables → добавьте:
   - DATABASE_URL — строка из Neon
   - NEXTAUTH_SECRET — любая длинная случайная строка
   - NEXTAUTH_URL — адрес сайта (https://имя.netlify.app)
   - AI_PROVIDER=gemini, AI_API_KEY — бесплатный ключ с aistudio.google.com/apikey, AI_MODEL=gemini-2.5-flash
   - CRYPTO_PAY_TOKEN — токен Crypto Pay
   - ADMIN_EMAIL — savelii@turenko.net
   - PRO_PRICE=9, VIP_PRICE=29, NEXT_PUBLIC_PRO_PRICE=9, NEXT_PUBLIC_VIP_PRICE=29
5. Deploys → Trigger deploy → Clear cache and deploy site.
6. @CryptoBot → Crypto Pay → ваше приложение → Webhooks → https://ВАШ-САЙТ/api/webhook
7. Зарегистрируйтесь на сайте с почтой savelii@turenko.net — откроется /admin.

Важно: на бесплатном Netlify функции живут ~10 сек. Если анализ обрывается — Site configuration → Functions → увеличьте таймаут (до 26 сек) или используйте платный план.
