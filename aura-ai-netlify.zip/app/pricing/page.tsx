import Plans from "@/components/Plans";
export default function Pricing() { return <><h1 className="text-3xl font-bold mb-6">Тарифы</h1><Plans /><p className="opacity-60 text-sm mt-4">Оплата криптовалютой через Crypto Bot. Подписка на 30 дней; для продления оплатите тариф ещё раз.</p></>; }
